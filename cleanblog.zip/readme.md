# CleanBlog

A very simple wordpress theme just only for blogging

![screenshot.png](https://bitbucket.org/repo/68MA97/images/2001133518-screenshot.png)

<a href="#">Download</a>